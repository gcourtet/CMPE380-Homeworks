/*
 ================================================================= 
 Student Header File for (Spline) Interpolation Module 
 Revised: JCCK. 11/18/2013
          R. Repka 11/10/2015 - Added NAN
          R. Repka 01/22/2017 - Removed not-a-not,natural & eval
 ================================================================= 
*/

#ifndef _INTERP_H_
#define _INTERP_H_

/* Data Types */
/* This is a container object used to pass the entire spline
   structure around.  Each pointer, points to a vector */
typedef struct
  {
   int     N_Splines; /* Number of Elements in array         */
   double *a;         /* Pointer to Constant coefficients    */
   double *b;         /* Pointer to Linear coefficients      */
   double *c;         /* Pointer to Quadratic coefficients   */
   double *d;         /* Pointer to Cubic coefficients       */
   double *X;         /* Pointer interpolation interval partition */
   } CSplines;

/* This is a container object used to pass the input points
   Each pointer, points to a vector.  y0 & yn contain optional
   initial conditions                                        */
typedef struct
  {
   int     N_Points;  /* Number of Elements in array  */
   double *X;         /* Pointer to X data            */
   double *Y;         /* Pointer to Y data            */
   double y0;         /* Derivative of first point, if any */
   double yn;         /* Derivative of last point, if any  */
  } Points;

  
/* Function Prototypes, add more if needed */
void cspline_clamped( Points* data, CSplines* splines);
void tridiagonal(double *p, double *q, double *r, double* x, double *B, int N);
void polySolve(CSplines *splines, double *h, Points *points);
void printSplines(CSplines *splines);
void s_alloc(CSplines *splines, int N);
void p_alloc(Points *points, int N);
void p_free(Points *points);
void s_free(CSplines *splines);
void printVector(double *vector, int N, const char *str);

#endif /*  _INTERP_H_ */
