/*******************************************************************
* interp.c - student file
*
* Finds splines from given points with different interpolation methods.
* 05/12/2016    R. Repka    - Minor clean up
* 01/22/2017    R. Repka    - Removed not-a-not and natural
* 04/12/2017    R. Repka    - minor comment clean-up
* 17/11/2017    R. Repka    - removed evaluation 
*******************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ClassErrors.h"
#include "interp.h"


/*****************************************************************************
 Finds the coefficients of the clamped cubic spline for a given set of data points
         (Prescribed 1st derivatives at end-points)  Requires N+1 coefficients
        so’ (xo) =  f ’ (x0 )      e.g. y0
        s’ (xn)  = f ’ (xn )       e.g. yn
        clamp end-points at prescribed angles
        
 Where Points *Data      - Pointer to Data Points array
       CSplines *Splines - Pointer to Spline Structure, data returned here 
                            Splines Coefficients of Cubic Spline Interpolants      
 Returns: Nothing
 Errors:  none
*****************************************************************************/
void cspline_clamped( Points* data, CSplines* splines){

    
    /***************  Pseudo code *******************************************
       Generate the h vector: hj = xj+1  -  xj
     
       Find the 0th alpha vector 
        alpha0 = 3((y1 - y0) - y0') 
                    --------
                       h0                 
    
       Find the alpha vector: notes: alphaj = 3(yj+1 - yj  - yj - yj-1)    j=1...n-1
                                              ------------  ------------    
                                                    hj         hj-1       
       Find the nth alpha vector
        alphan = 3(yn' - (yn - yn-1)  )
                          ----------
                              hn-1             

       Generate the outside symmetric tri-diagonal matrix 
       Generate the center diagonal of the symmetric tri-diagonal matrix 
       Use the general tri-diagonal solver to find spline data c 
       Copy the solution of the tri-diagonal value c into the spline structure 
       **********************************************************************/
 
}


/***************************************************************************************
 Solves the tridiagonal matrix (3 vectors really) into the array x
             Uses:  Ax=B,  LU factorization:  Lz = B, Ux=z
 
 Where: double *p - pointer to the bottom outer vector - part of L
        double *q - pointer to the center vector          - part of U
        double *r - pointer to the top other outer vector - part of U
        double* x - resulting solution vector, x returned, the logical spline "c"
        double *B - pointer to value matrix - alpha
        int N     - Number of elements in the matrix
  Returns: nothing
  Errors:  prints an error and exits
*****************************************************************************************/
void tridiagonal(double *p, double *q, double *r, double* x, double *B, int N){
 
    
    /* LU Factorization or Elimination, right from the notes */
 
}


/***************************************************************************************
 Finds the A, B, D, and X poly values using the following
        aj = yj
        bj = yj+1 - yj      cj+1 + 2cj
            ----------- -  ---------- hj
                hj             3
        cj = passed in from tridiagional solution
        dj = cj+1 - cj
            -----------
                3h
  
 Where: CSplines *Splines - Pointer to Spline Structure, data returned here    
        double *h         - difference vector: e.g. hj = xj+1  -  xj*
        Points *points    - Pointer to Data Points array                            
 Returns: nothing
 Errors:  none 
*****************************************************************************************/
void polySolve(CSplines *splines, double *h, Points *points){
        /*  aj = yj */
       
        
        /*  b[j] = yj+1 - yj      cj+1 + 2cj
                  ----------- -  ---------- hj
                       hj             3         */
         
        /* d[j] = cj+1 - cj
                -----------
                     3h        */
        
        /* Copy the associated points */
   
}


/***************************************************************************************
 Prints the splines to standard out 
            of the form:  X0 X1 d c b a
 
 Where: CSplines *Splines - Pointer to Spline Structure to print                          
 Returns: nothing
 Errors:  none 
*****************************************************************************************/
void printSplines(CSplines *splines){
  
}

/***************************************************************************************
 Allocates space for the splines
 
  Where: CSplines *Splines - Pointer to Spline Structure to allocate.  
                            Note the "c" & "X" entry allocation is N+1 because some spine 
                            calculations require extra terms.
         int N             - The number of splines required 
 Returns: nothing
 Errors:  prints an error message and exits 
*****************************************************************************************/
void s_alloc(CSplines *splines, int N){

}

/***************************************************************************************
 Frees the spline 
 
 Where: CSplines *Splines - Pointer to Spline Structure to free    
 Returns: nothing
 Errors:  none
*****************************************************************************************/
void s_free(CSplines *splines){
 
}

/***************************************************************************************
 Allocates space to hold the points 
 
 Where: Points *points - Pointer to Points Structure to allocate    
        int N          - The number of splines required 
 Returns: nothing
 Errors:  prints an error message and exits 
*****************************************************************************************/
void p_alloc(Points *points, int N){
 
}

/***************************************************************************************
 Frees the values in the points structure
 
 Where: Points *points - Pointer to Points Structure to free    
 Returns: nothing
 Errors:  none 
*****************************************************************************************/
void p_free(Points *points){
  
}

/***************************************************************************************
 Optional, prints a simple vector of N numbers with a comment
 
 Where: double *vector  - Pointer to the real vector
        int N           - number of terms to print
        const char *str - Comment string 
 Returns: nothing
 Errors:  none 
*****************************************************************************************/
 void printVector(double *vector, int N, const char *str) {

 }