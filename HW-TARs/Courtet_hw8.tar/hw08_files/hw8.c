/********************************************************************
 * Applied Programming:
 *    Solution of Overdetermined System of Equations Ax=b arising
 *    in least square problems via QR factorizations using the GSL                                                 *
 * Compilation:  gcc -ansi -g -lgsl -lgslcblas  hw8.c DynamicArrays.c -o  hw8
 *
 * Tested in Ubuntu 12.04 LTS
 * Revised: Juan C. Cockburn, April 9, 2015 (juan.cockburn@rit.edu)
 * 10/10/2015 R. Repka - Minor clean up
 * 10/26/2016 R. Repka - Major re-write, added QR and norm solution modes
 * 11/12/2017 R. Repka - Minor comment change for norm of residuals, removed
 *                       "c" in GE_FindPoint
 * 11/28/2016 R. Repka - Added Pearson function
 * 07/11/2017 R. Repka  - Switched to getopt_long_only
 ********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string.h>
#include <getopt.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_linalg.h>
#include <math.h>
#include "ClassErrors.h"
#include "DynamicArrays.h"

#define MAX_STR_LEN (256)
#define INITIAL_SIZE (500)

/*****************************************************************************
 Function prototypes
*****************************************************************************/
void readPoints (FILE *file, DArray *DArrayPtr);
void Norm_FindPoint(int nr, int nc, const DArray *points, gsl_vector *x_ls,
                                                                 int verbose);
void GE_FindPoint(int nr, int nc, const DArray *points, gsl_vector *x_ls,
                                                                 int verbose);
double RSquareError(int nr, int nc, const DArray *points,
                                                      const gsl_vector *x_ls);
double normOfResiduals(int nr, int nc, const DArray *points,
                                                      const gsl_vector *x_ls);
double pearson_correl(int nr, int nc, const DArray *points,
                                                      const gsl_vector *x_ls);
double evalPoly(int nc, double x, const gsl_vector *x_ls);


/*****************************************************************************
 This program uses least squares to generate approximate functions
    usage: hw8 (-ge | -norm) -order  num   -points  file  [-verbose] \n");

 Returns: 0 for success, non-zero for errors
 *****************************************************************************/


 /* gcc -Wall -std=c99 -O3 -pedantic -g -DHW8 -lm -lgsl -lgslcblas DynamicArrays.c hw8.c -o hw8 */

int main(int argc, char *argv[])
{
  DArray points;
  FILE *pointsFile;
  gsl_vector *x_ls; /* least squares solution   */

  enum modes {UNDEF, GE, NORM} mode = UNDEF;
  unsigned int nc = 0;
  unsigned int nr = 0;

  /*------------------------------------------------------------------------
  UI variables with sentential values
  ------------------------------------------------------------------------*/
    int verbose = 0;
    char* fileName = "";

  /*------------------------------------------------------------------------
  These variables are used to control the getopt_long_only command line
  parsing utility.
  ------------------------------------------------------------------------*/
    int rc = 0;
    /* getopt_long stores the option index here. */
    int option_index = 0;

    /* This contains the short command line parameters list */
    char *getoptOptions = "gno:p:v";    /* add lots of stuff here */

    /* This contains the long command line parameter list, it should mostly
    match the short list                                                  */
    struct option long_options[] = {
      /* These options don’t set a flag.
      We distinguish them by their indices. */
      {"verbose",   no_argument,       0, 'v'},
      {"verb",      no_argument,       0, 'v'},
      /* add lots of stuff here */
      {"points",   required_argument,       0, 'p'},
      {"order",    required_argument,       0, 'o'},
      {"ge",       no_argument,       0, 'g'},
      {"norm",     no_argument,       0, 'n'},

      {0, 0, 0, 0}
    };

    opterr = 1;           /* Enable automatic error reporting */
    while ((rc = getopt_long_only(argc, argv, getoptOptions, long_options,
                                          &option_index)) != -1) {

      //     printf("getopt_long_only() returned ='%c' index = '%d'\n",  rc, option_index);
      /* Detect the end of the options. */
      switch (rc) {
        case 'v':                    /* verbose */
          printf("option -v\n");
          verbose = 1;
        break;

        case 'p':                    /* points */
          printf("option -p\n");
          fileName = optarg;
        break;

        case 'o':                    /* order */
          printf("option -o\n");
          nc = atoi(optarg) + 1; /* order n means (n+1) coefficient */
        break;

        case 'g':                    /* ge */
          printf("option -g\n");
          mode = GE;
        break;

        case 'n':                    /* norm */
          printf("option -n\n");
          mode = NORM;
        break;

        case '?':  /* Handled by the default error handler */
        break;

        default:
          printf ("Internal error: undefined option %0xX\n", rc);
          exit(PGM_INTERNAL_ERROR);
      } /* switch */
    } /* end while */

    /*------------------------------------------------------------------------
    Check for command line syntax errors
    ------------------------------------------------------------------------*/
    if ((optind < argc) || 0 == strcmp("", fileName) || UNDEF == mode || 0 == nc){
      fprintf(stderr, "GE and Norm Least Squares data fitting using GSL\n");
      fprintf(stderr, "usage: hw8 (-ge | -norm) -o[rder] num -p[oints] file [-v[er[bose]]]\n");
      fprintf(stderr, " e.g:   hw8 -ge -o 2 -p data.txt\n");
      fflush(stderr);
      return(PGM_INTERNAL_ERROR);
    } /* end if error */

    pointsFile = fopen(fileName, "r"); /* open the file */

    /* if our file is NULL */
    if(NULL == pointsFile) {
      fprintf(stderr, "Error in file %s at line number %d: file %s was not opened correctly\n", __FILE__, __LINE__, fileName);

      /* return error code */
      return PGM_FILE_NOT_FOUND;
    }

    /* read the point and store them in the DArray */
    readPoints(pointsFile, &points);

    /* close the file */
    fclose(pointsFile);

    /* create result vector */
    x_ls = gsl_vector_alloc(nc);

    /* get the size for the matrix */
    nr = points.EntriesUsed;

      /* different behavior depending on the command line arguments */
       switch(mode) {
         case GE:
          fprintf(stdout, "Least Squares Solution via GE:\n");
          GE_FindPoint(nr, nc, &points, x_ls, verbose);
         break;

         case NORM:
          fprintf(stdout, "Least Squares Solution via Norm factorization:\n");
          Norm_FindPoint(nr, nc, &points, x_ls, verbose);
         break;

         default:
           fprintf(stderr, "Error in file %s at nr number %d: no mode was specified\n", __FILE__, __LINE__);

           /* return error code */
           return PGM_INTERNAL_ERROR;
       } /* switch */

    /* print resulting polynomial */
    unsigned int i = 0;
    fprintf(stdout, "f(x) = ");
    fprintf(stdout, "%g", gsl_vector_get(x_ls, i));
    /* print the other terms only if different from 0*/
    for(i = 1; i < nc; i++) {
        fprintf(stdout, " + ");
        if(i > 1) {
          fprintf(stdout, "%gx^%d", gsl_vector_get(x_ls, i), i);
        } else {
          fprintf(stdout, "%gx", gsl_vector_get(x_ls, i));
        } /* if ... else */
    } /* for */

    fprintf(stdout, "\n");

    /* compute errors */
    double residual = 0, deter_coef = 0, person = 0;
    deter_coef = RSquareError(nr, nc, &points, x_ls);
    residual = normOfResiduals(nr, nc, &points, x_ls);
    person = pearson_correl(nr, nc, &points, x_ls);

    /* print results */
    fprintf(stdout, "Norm of Residuals error = %f\n", residual);
    fprintf(stdout, "R**2 determination coef =  %f\n", deter_coef);
    fprintf(stdout, "Pearson Correlation = %f\n", person);

     /* Clean up */
   gsl_vector_free(x_ls);
   DestroyDArray(&points);

  return PGM_SUCCESS; /* main */
}


/*---------------------------------------------------------------------------
  Find the least squares approximation to data "points" of order "nc" using
  the Gaussian Elimination approach.

  Where: int nr           - The number of points (rows) of the input file
         int nc           - The number of columns (order) of the solution
         DArray *points   - Pointer to the x,y data
         gsl_vector *x_ls - The solution is returned here
         int verbose      - Verbose flag

  Returns: nothing
  Errors: Assumes the standard GSL error handler
---------------------------------------------------------------------------*/
void GE_FindPoint(int nr, int nc, const DArray *points, gsl_vector *x_ls, int verbose) {
   unsigned int i = 0, j = 0; /* loop variables */

   gsl_matrix *A;    /* coefficient matrix       */
   gsl_vector *b;    /* coefficient vector       */
   gsl_vector *tau;  /* Householder coefficients */
   gsl_vector *res;  /* vector of residuals      */

   /* Allocate space for Matrices and vectors */
   A   = gsl_matrix_alloc(nr, nc); /* Data matrix */
   b   = gsl_vector_alloc(nr);     /* Data vector */
   tau = gsl_vector_alloc(nc);     /* required place holder for GSL */
   res = gsl_vector_alloc(nr);     /* Contains the residual */



   /*------------------------------------------------------------------------
     your code here, GSL fragments you might find useful
      gsl_matrix_set(A, i, j, x);
      gsl_vector_set(b, i, y);

      gsl_matrix_get(A, i, j));
      gsl_vector_get(b, i));
   ------------------------------------------------------------------------*/
   /* insert data into A and b  */
   /* variables for computation */
    double temp_x = 0;
    double x = 0;
    double y = 0;
    for(i = 0; i < nr; ++i) {
      temp_x = 1.0;
      x = points->Payload[i].x;
      y = points->Payload[i].y;
      for(j = 0; j < nc; ++j) {
        gsl_matrix_set(A, i, j, temp_x);
        temp_x *= x;
      } /* for j */
      gsl_vector_set(b, i, y);
    } /* for i */

    /* print A and b if verbose is set */
    if(1 == verbose) {
      fprintf(stdout, "A(%d x %d)\n", nr, nc);
      for(i = 0; i < nr; i++) {
        fprintf(stdout, "%d: ", i);
        for(j = 0; j < nc; j++) {
          fprintf(stdout, "%f ", gsl_matrix_get(A, i, j));
        } /* for j */
        fprintf(stdout, "\n");
      } /* for i */

      fprintf(stdout, "\n");
      fprintf(stdout, "\n");

      fprintf(stdout, "b(%d x 1)\n", nr);
      for(i = 0; i < nr; i++) {
        fprintf(stdout, "%d: %f\n", i, gsl_vector_get(b, i));
      } /* for */

      fprintf(stdout, "\n");
      fprintf(stdout, "\n");
    } /* if */

   /*  Solve Ax=b directly via QR factorization */
   /*  Find QR decomposition: (note that gls_linalg_QR_decomp overwrites A )
    *  On return, the vector tau and the columns of the lower triangular part of
    *  the matrix A have the Householder coefficients and vectors */
   gsl_linalg_QR_decomp(A, tau);


   /* Solve R x_ls = Q^T b, R is upper triangular */
   /* Note that we pass the "overwritten A", tau and b as input arguments
    * On return x_ls has the least square solution and res the residual vector Ax-b  */
   gsl_linalg_QR_lssolve(A, tau, b, x_ls, res);

   /* print x_ls if verbose is set */
   if(1 == verbose) {
     for(i = 0; i < nc; i++) {
       fprintf(stdout, "x_ls[%d] = %.16lf\n", i, gsl_vector_get(x_ls, i));
     } /* for */
     fprintf(stdout, "\n");
     fprintf(stdout, "\n");
   } /* if */

  /* Free memory  */
  gsl_matrix_free(A);
  gsl_vector_free(b);
  gsl_vector_free(tau);
  gsl_vector_free(res);
} /* End GE_FindPoint() */

/*---------------------------------------------------------------------------
  Find the least squares approximation to data "points" of order "nc" using
  the "Normal equations" approach.

                        A'Az = A'b

  Where: int nr           - The number of points (rows) of the input file
         int nc           - The number of columns (order) of the solution
         DArray *points   - Pointer to the x,y data
         gsl_vector *x_ls - The solution is returned here
         int verbose      - Verbose flag

  Returns: nothing
  Errors: Assumes the standard GSL error handler
---------------------------------------------------------------------------*/
void Norm_FindPoint(int nr, int nc, const DArray *points, gsl_vector *x_ls, int verbose) {
   unsigned int i = 0, j = 0; /* loop variables */
   gsl_matrix *A;    /* coefficient matrix A     */
   gsl_matrix *AT;   /* coefficient matrix A'    */
   gsl_matrix *ATA;  /* coefficient matrix A'A   */
   gsl_vector *b;    /* coefficient vector b     */
   gsl_vector *ATB;  /* coefficient vector A'b   */
   gsl_vector *tau;  /* Householder coefficients */
   gsl_vector *res;  /* vector of residuals      */

   /* Allocate space for Matrices and vectors */
   ATA  = gsl_matrix_alloc(nc, nc); /* Data matrix */
   AT   = gsl_matrix_alloc(nc, nr); /* Data matrix */
   A    = gsl_matrix_alloc(nr, nc); /* Data matrix */
   b    = gsl_vector_alloc(nr);     /* Data vector */
   ATB  = gsl_vector_alloc(nc);     /* Data vector */
   tau  = gsl_vector_alloc(nc);     /* required place holder for GSL */
   res  = gsl_vector_alloc(nc);     /* Contains the residual */

  /* your code here  */

  /* insert data into A and b  */
  /* variables for computation */
  double temp_x = 0;
  double x = 0;
  double y = 0;
  for(i = 0; i < nr; ++i) {
    temp_x = 1.0;
    x = points->Payload[i].x;
    y = points->Payload[i].y;
    for(j = 0; j < nc; ++j) {
      gsl_matrix_set(A, i, j, temp_x);
      temp_x *= x;
    } /* for j */
    gsl_vector_set(b, i, y);
  } /* for i */

  /* transpose A into AT*/
  gsl_matrix_transpose_memcpy (AT, A);

  /* compute ATA */
  gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, AT, A, 0.0, ATA);

  /* compute ATB */
  gsl_blas_dgemv(CblasNoTrans, 1.0, AT, b, 0.0, ATB);

  /*  Solve ATA=ATb directly via QR factorization */
  gsl_linalg_QR_decomp(ATA, tau);

  /* Solve ATA x_ls = ATB, ATA is upper triangular */
  gsl_linalg_QR_lssolve(ATA, tau, ATB, x_ls, res);

  /* print A, b, AT, ATA, ATB and x_ls if verbose is set */
  if(1 == verbose) {
    /* print A */
    fprintf(stdout, "A(%d x %d)\n", nr, nc);
    for(i = 0; i < nr; i++) {
      fprintf(stdout, "%d: ", i);
      for(j = 0; j < nc; j++) {
        fprintf(stdout, "%f ", gsl_matrix_get(A, i, j));
      } /* for j */
      fprintf(stdout, "\n");
    } /* for i */

    fprintf(stdout, "\n");
    fprintf(stdout, "\n");

    /* print b */
    fprintf(stdout, "b(%d x 1)\n", nr);
    for(i = 0; i < nr; i++) {
      fprintf(stdout, "%d: %f\n", i, gsl_vector_get(b, i));
    } /* for */

    fprintf(stdout, "\n");

  /* print AT */
    fprintf(stdout, "AT(%d x %d)\n", nc, nr);
    for(i = 0; i < nc; i++) {
      fprintf(stdout, "%d: ", i);
      for(j = 0; j < nr; j++) {
        fprintf(stdout, "%f ", gsl_matrix_get(AT, i, j));
      } /* for j */
      fprintf(stdout, "\n");
    } /* for i */

    fprintf(stdout, "\n");
    fprintf(stdout, "\n");

  /* print ATA */
    fprintf(stdout, "ATA(%d x %d)\n", nc, nc);
    for(i = 0; i < nc; i++) {
      fprintf(stdout, "%d: ", i);
      for(j = 0; j < nc; j++) {
        fprintf(stdout, "%f ", gsl_matrix_get(ATA, i, j));
      } /* for j */
      fprintf(stdout, "\n");
    } /* for i */

    fprintf(stdout, "\n");
    fprintf(stdout, "\n");

  /* print ATB */
    fprintf(stdout, "ATB(%d x 1)\n", nc);
    for(i = 0; i < nc; i++) {
      fprintf(stdout, "%d: %f\n", i, gsl_vector_get(ATB, i));
    } /* for */
    fprintf(stdout, "\n");
    fprintf(stdout, "\n");

  /* print x_ls */
    for(i = 0; i < nc; i++) {
      fprintf(stdout, "x_ls[%d] = %.16lf\n", i, gsl_vector_get(x_ls, i));
    } /* for */
    fprintf(stdout, "\n");
    fprintf(stdout, "\n");
  } /* if */

  /* Free memory  */
  gsl_matrix_free(A);
  gsl_matrix_free(AT);
  gsl_matrix_free(ATA);
  gsl_vector_free(b);
  gsl_vector_free(ATB);
  gsl_vector_free(tau);
  gsl_vector_free(res);
} /* end Norm_FindPoint() */



/****************************************************************************
  This calculate the norm of residuals given the points and the solution

                   normR = squareRoot [sum ( yi - f(x)i}**2 ]

  Where: int nr           - The number of points (rows) of the input file
         int nc           - The number of columns (order) of the solution
         DArray *points   - Pointer to the x,y data
         gsl_vector *x_ls - The solution vector, small power first

  Errors: Assumes the standard GSL error handler

  Returns: double norm of residuals
****************************************************************************/
double normOfResiduals(int nr, int nc, const DArray *points, const gsl_vector *x_ls) {
  /* variables for computation */
  double temp = 0, x = 0, y = 0, sum = 0;
  unsigned int i = 0;

  for(i = 0; i < nr; ++i) {
      x = points->Payload[i].x;
      y = points->Payload[i].y;
      temp = y - evalPoly(nc, x, x_ls);
      sum +=  temp * temp; /* [yi - f(xi)]**2 */
  } /* for */

  return sqrt(sum); /* sqrt(sum[[yi - f(xi)]**2]) */
} /* normOfResiduals */


/****************************************************************************
  This calculate the R2 coefficient of Determination error between the points
  and the solution

  Where: int nr           - The number of points (rows) of the input file
         int nc           - The number of columns (order) of the solution
         DArray *points   - Pointer to the x,y data
         gsl_vector *x_ls - The solution vector, small power first

  Errors: Assumes the standard GSL error handler

  Returns: R squared error
****************************************************************************/
double RSquareError(int nr, int nc, const DArray *points, const gsl_vector *x_ls) {

  /* variables for computation */
  double x = 0, y = 0, u = 0, num = 0, temp = 0, denom = 0, res = 0;
  unsigned int i = 0;

  for(i = 0; i < nr; ++i) {
      x = points->Payload[i].x;
      y = points->Payload[i].y;
      temp = y - evalPoly(nc, x, x_ls);
      num +=  temp * temp; /* sum[[yi - f(xi)]**2] */
  } /* for */

  for(i = 0; i < nr; ++i){
    y = points->Payload[i].y;
    u += (1.0 / nr) * y; /* u = 1/n * sum(yi) */
  } /* for */

  for(i = 0; i < nr; ++i) {
      y = points->Payload[i].y;
      temp = y - u;
      denom +=  temp * temp; /* sum[[yi - u]**2] */
  } /* for */

  res = 1.0 - (num / denom);

  return res;
} /* End RSquareError */


/*****************************************************************************
 This calculates the Pearson's Correlation, or the excel function correl()

  Where: int nr           - The number of points (rows) of the input file
         int nc           - The number of columns (order) of the solution
          DArray *points   - Pointer to the x,y data
         gsl_vector *x_ls - The solution vector, small power first

  Errors: Assumes the standard GSL error handler

 Returns: double pearson_srq
*****************************************************************************/
double pearson_correl(int nr, int nc, const DArray *points,
                                              const gsl_vector *x_ls) {

  /* variables for computation */
  double sum_y = 0, sum_f = 0, sum_yf = 0, sum_yy = 0, sum_ff = 0, num = 0, denom = 0, x = 0, y = 0, f = 0;
  unsigned int i = 0;

  /* compute all sums */

  /* sum yi and sum yi**2 */
  for(i = 0; i < nr; ++i){
    y = points->Payload[i].y;
    sum_y += y;
    sum_yy += y * y;
  } /* for */

  /* sum yi*f(xi) */
  for(i = 0; i < nr; ++i){
    x = points->Payload[i].x;
    y = points->Payload[i].y;
    f = evalPoly(nc, x, x_ls);
    sum_yf += y * f;
  } /* for */

  /* sum f(xi) and sum f(xi)**2*/
  for(i = 0; i < nr; ++i){
    x = points->Payload[i].x;
    f = evalPoly(nc, x, x_ls);
    sum_f += f;
    sum_ff += f * f;
  } /* for */

  /* compute numerator */
  num = nr * sum_yf - sum_y * sum_f;

  /* compute denominator */
  denom = (nr * sum_yy - sum_y * sum_y) * (nr * sum_ff - sum_f * sum_f);

  /* compute and return result */
  return num / sqrt(denom);


} /* End pearson_correl */




/***************************************************************************************
 Evaluates a polynomial at a point, assumes low order term first.  Must use Horner's
 factorization

 Where: int nc           - The number of columns in the solution
        double x         - Point at which splines should be evaluated
        gsl_vector *x_ls - The solution vector, small power first

 Returns: double - The value at the desired point
 Errors:  none
*****************************************************************************************/
double evalPoly(int nc, double x, const gsl_vector *x_ls) {
  /* result is 0 to begin with */
  double result = 0.0 ;

  /* loop variable */
  int i;

  /* using Horner's factorization */
  for(i = nc - 1; i >= 0; i--) {
    /* result is previous result * point to evaluate + coefficient */
    /* eg: ax^2 + bx + c = (ax + b)x + c */

    result = result * x + gsl_vector_get(x_ls, i);
  } /* for */


  return result;
} /* End evalPoly */


/***************************************************************************************
 Reads the points data from file and returns it in a Darray

 Where: FILE *file     - open handle to read from
                         of the form:     22.0      6.7
                                          23.4      18.8
        DArray *DArrayPtr - Pointer to a dynamic array to store the data
  Returns: nothing
  Errors:  none
*****************************************************************************************/
void readPoints(FILE *file, DArray *DArrayPtr)
{

      /* allocate that DArray */
      CreateDArray(DArrayPtr, INITIAL_SIZE);

      char String[MAX_STR_LEN+2]; /* temp variable to hold string */
      char* delim = " \t";          /* delimiter to split the line */
      char *value;                /* string to hold the points read */
      unsigned int numbersOnLine = 0; /* number of points on line */
      Data data; /* variable to hold the data read */

      /* Read the data in from the file into the String buffer */
      while (NULL != fgets(String, MAX_STR_LEN, file)) {
        /* get the first token */
        value = strtok(String, delim);

        /* walk through other tokens */
        while(NULL != value) {
          /* what number are we reading ? x or y */
          switch (numbersOnLine) {
            case 0:
             data.x = atof(value);
            break;

            case 1:
             data.y = atof(value);
            break;

            default:
              fprintf(stderr, "Error in file %s at line number %d: file was not in correct format (too many values on line)\n", __FILE__, __LINE__);

              /* return error code */
              exit(PGM_INTERNAL_ERROR);
          }

          /* we've read one number so we get the next one */
          numbersOnLine++;
          value = strtok(NULL, delim);
        } /* while */

        /* add read data to Darray */
        PushToDArray(DArrayPtr, &data);

        /* reinitialize the number of points on line */
        numbersOnLine = 0;
      } /* while */

  return;
} /* readPoints */
