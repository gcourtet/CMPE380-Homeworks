/******************************************************************
 * Program to correct the data for the sensor
 * Note: Each student gets unique data, so this exact equation will
 * differ for each students solution
 * Be sure to use Honer's factorization
 * ***************************************************************/

#include <stdio.h>
#include <stdlib.h>

/* Runs the data through the fitting line */

static int correctData(int order, int x, const double *coeffs);

int main(int argc, char *argv[])
{
    int res, real, ideal;

    while(scanf("%d %d", &ideal, &real) != EOF)
    {
     /* Insert your polynomial here, be sure to round properly */

      /* array of double used to store the polynomial coefficient (low order first) + its size */

      /* USING NORM */
      /* 1st order */
      /* double poly_coeff[2] = {98.424943, 7.567336e-02};
      unsigned int poly_size = 2; */

      /* 2nd order */
      /* double poly_coeff[3] = {-45.622065, 2.595375e-01, -4.103725e-05};
      unsigned int poly_size = 3; */

      /* 3rd order (MY CHOICE) */
      double poly_coeff[4] = {32.929288, 6.707312e-02, 6.560818e-05, -1.613260e-08};
      unsigned int poly_size = 4;

      /* 4th order */
      /* double poly_coeff[5] = {67.274754, 4.353100e-02, 4.287846e-05, 7.427853e-10, -2.578677e-12};
      unsigned int poly_size = 5; */

      /* 5th order */
      /* double poly_coeff[6] = {-83.505434, 4.182185e-01 , -2.043859e-04, 4.123389e-08, 4.839387e-12, -1.838082e-15};
      unsigned int poly_size = 6; */

      /* USING GE */
      /* 1st order */
      /* double poly_coeff[2] = {9.842494e+01, 7.567336e-02};
      unsigned int poly_size = 2; */

      /* 2nd order */
      /* double poly_coeff[3] = {-4.562205e+01, 2.595375e-01, -4.103725e-05};
      unsigned int poly_size = 3; */

      /* 3rd order */
      /* double poly_coeff[4] = {3.292450e+01, 6.708140e-02, 6.560433e-05, -1.613208e-08};
      unsigned int poly_size = 4; */

      /* 4th order */
      /* double poly_coeff[5] = {-3.291054e+01, 3.204702e-01, -1.830098e-04, 7.129820e-08, -1.003677e-11};
      unsigned int poly_size = 5; */

      /* 5th order */
      /* double poly_coeff[6] = {4.184657e+01, -8.179769e-02, 4.159148e-04, -2.862334e-07, 8.202449e-11, -8.526661e-15};
      unsigned int poly_size = 6; */

      /* correct the data at each point */
      res = correctData(poly_size, real, poly_coeff);

      /* print result to stdout */
      printf("%d %d\n", ideal, res);
    }
    return 0;
}


/***************************************************************************************
Corrects the data at a point, assumes low order term first.  Uses Horner's
 factorization

 Where: int order           - The order of the polynomial
        int x         - Point at which we want to correct the data
        double *coeffs - The polynomial coefficient vector (low order first)

 Returns: int - The corrected value at the desired point
 Errors:  none
*****************************************************************************************/
static int correctData(int order, int x, const double *coeffs) {
  /* result is 0 to begin with */
  double result = 0.0;

  /* loop variable */
  int i;

  /* using Horner's factorization, we evaluate the polynomial at point x */
  for(i = order - 1; i >= 0; i--) {
    /* result is previous result * point to evaluate + coefficient */
    /* eg: ax^2 + bx + c = (ax + b)x + c */

    result = result * x + coeffs[i];
  } /* for */

  int res;

  /* we then round the result */
  res = result >= 0 ? (int)(result + 0.5) : (int)(result - 0.5);

  /* and apply the correction to the initial value */
  res = x - res;

  return res;
} /* End evalPoly */
