/**************************************************************************
 ** Linear Curve Fitting
 **   This program fits a line to the data points in the text file provided
 **   on the command line (one data point per line)
 **
 ** Revised: Juan C. Cockburn - 9/11/2014
 **          R. Repka         -12/12/2015 - added error checking
  **         R. Repka         -02/20/2016 - Added include file hint
 **************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* add other include files as necessary */
#include "Timers.h"

/* Constants for the iterations */
#define IO_ITERATIONS 1000
#define PROCESS_ITERATIONS 100000

/* structure to hold header of dynamic array */
typedef struct {
   double *Data_X;      /* Pointer to X data dynamic array */
   double *Data_Y;      /* Pointer to X data dynamic array */
   unsigned int Size;            /* Current Size of dynamic arrays */
   unsigned int NextElement;     /* Index of element next to last used entry in the arrays */
  } LinearFit;

/* Function prototypes */
void CalculateCoefficients(LinearFit *DataSet, double *A, double *B);
void AddPoint(LinearFit *DataSet, double *X, double *Y);

/**************************************************************************
* Main program to fit a line to a data set using "batch" least squares
**************************************************************************/
int main(int argc, char *argv[])
  {
   /* Declare a LinearFit data structure */
   LinearFit DataSet;

   double A, B; /* Variables for coefficients of least-square line       */
   double X, Y; /* Temporary variables to hold data point read from file */
   unsigned int Done;    /* "Boolean" variable to indicate all data has been read */
   FILE *InputFile = NULL; /* Input file pointer for data file                  */

   /* Check that a command line argument was provided */
   if (1 != argc)
    {

    /* Start with minimally sized arrays */
    DataSet.Size = 100;

    /* Allocate the arrays */
    DataSet.Data_X = (double *)malloc(sizeof(double) * DataSet.Size);
    DataSet.Data_Y = (double *)malloc(sizeof(double) * DataSet.Size);

    if ((NULL == DataSet.Data_X) || (NULL == DataSet.Data_Y))
       {
        fprintf(stderr, "Error: Could not allocate memory at line %d\n", __LINE__);
        exit(-99);
       }

    DECLARE_TIMER(data_timer)
    DECLARE_REPEAT_VAR(data)
    START_TIMER(data_timer)
    BEGIN_REPEAT_TIMING(IO_ITERATIONS,data)
    /* Initialize the index where the next data point will go */
    DataSet.NextElement = 0;

    /* Open input file for reading -- it should be a valid filename */
    InputFile = fopen(argv[1], "r");
    if (NULL == InputFile)
       {
       fprintf(stderr, "Error: Input file '%s' not found\n", argv[1]);
       return(-1);
       }

    /* Read all of the data from the file */
    do {
       /* Read X,Y data point and if read did not go beyond end-of-file,
          add it to the data set */
       if (fscanf(InputFile, "%lf %lf", &X, &Y) != EOF)
         {
          /* Append the new data point to the array */
          AddPoint(&DataSet, &X, &Y);
          Done = 0;
         } /* if() */
       else
         {
          /* Set flag indicating that all the data has been read */
          Done = 1;
         } /* if...else() */
    } while (!Done);

    /* Disconnect the input file from the stream */
    fclose(InputFile);

    END_REPEAT_TIMING
    STOP_TIMER(data_timer)
    PRINT_TIMER(data_timer)
    PRINT_RTIMER(data_timer,IO_ITERATIONS)

    DECLARE_TIMER(process_timer)
    DECLARE_REPEAT_VAR(process)
    START_TIMER(process_timer)
    BEGIN_REPEAT_TIMING(PROCESS_ITERATIONS,process)

    /* Compute the coefficients of the least squares line */
    CalculateCoefficients(&DataSet, &A, &B);

    END_REPEAT_TIMING
    STOP_TIMER(process_timer)
    PRINT_TIMER(process_timer)
    PRINT_RTIMER(process_timer,PROCESS_ITERATIONS)

    /* Return dynamic memory for data to the heap */
    free(DataSet.Data_X);
    free(DataSet.Data_Y);

    /* Print out the line that fits the data set. */
    printf("The best least square line is: Y = %g * X + %g\n", A, B);

    } /* if() */
  else
    {
      /* Display program usage information */
      printf("Fits a line to data points\n");
      printf("(C Version) Usage: %s Filename\n", argv[0]);
    } /* if...else() */

   return 0;
  } /* main() */

/**************************************************************************
* AddPoint() - Accepts a single point and appends it to the array expanding
*              the size of the arrays if necessary.
**************************************************************************/
void AddPoint(LinearFit *DataSet, double *X, double *Y)
  {
   unsigned int next_element = DataSet->NextElement;
   DataSet->Data_X[next_element] = *X;
   DataSet->Data_Y[next_element] = *Y;

   /* Increment index for the next point and see if that point will be */
   /* beyond the size of the arrays */
   if (++DataSet->NextElement >= DataSet->Size)
     {
      /* Increase the size of the arrays by 1 */
      DataSet->Size *= 2;
      unsigned int size = DataSet->Size;

      /* Declare AND allocate new (larger) arrays for the additional data */
      DataSet->Data_X = (double *)realloc(DataSet->Data_X, sizeof(double) * size);
      DataSet->Data_Y = (double *)realloc(DataSet->Data_Y, sizeof(double) * size);

      /* Check for any errors */
      if ((NULL == DataSet->Data_X) || (NULL == DataSet->Data_Y))
         {
          fprintf(stderr, "Error: Could not allocate memory at line %d\n", __LINE__);
          exit(-99);
         }

     } /* if() */
  } /* AddPoint() */


/**************************************************************************
*  CalculateConstant() - Calculate coefficients A and B best linear fit
*                        equation: Y = A * X + B
**************************************************************************/
void CalculateCoefficients(LinearFit *DataSet, double *A, double *B)
  {
   /* Declare and initialize sum variables */
   double S_XX = 0.0;
   double S_XY = 0.0;
   double S_X  = 0.0;
   double S_Y  = 0.0;
   unsigned int lcv;

   unsigned int next_element = DataSet->NextElement;

   /* Compute the sums */
   for (lcv=next_element; lcv--;)
    {
      S_XX += DataSet->Data_X[lcv] * DataSet->Data_X[lcv];
      S_XY += DataSet->Data_X[lcv] * DataSet->Data_Y[lcv];
      S_X  += DataSet->Data_X[lcv];
      S_Y  += DataSet->Data_Y[lcv];
    } /* for() */

   /* Compute the parameters of the line Y = A*X + B */
   (*A) = (((next_element * S_XY) - (S_X * S_Y)) / ((next_element * S_XX) - (S_X * S_X)));
   (*B) = (((S_XX * S_Y) - (S_XY * S_X)) / ((next_element * S_XX) - (S_X * S_X)));
  } /* CalculateCoefficients() */

