/******************************************************************************
 An student framework implementation to test the LinkedLists module.
 Reads in a large list of words and puts them into the data structure,
 then prints out the first and last six elements in the data structure as
 well as the total number of words.
 Note: This is only a framework, it does not include ALL the functions or
       code you will need.
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ClassErrors.h"
#include "LinkedLists.h"

/* Local functions */
void ReadDataList(FILE *InputFile, LinkedLists *ListPtr);
/******************************************************************************
 Program to test the Data structure by reading the Data file provided on
 the command line into the structure, printing out the first and last five
 elements and total number of elements.

 Where: int argc     - the number of parameters on the command line
        char *argv[] - Pointer to the command line parameters
 Returns: 0 - success,
          2 - can't open input file
          1 - Invalid number of parameters
******************************************************************************/
int main(int argc, char* argv[])
  {
  /* declare local variables */
  int ErrorCode = 0;        /* Application error code - 0 is OK */
  LinkedLists TestLinkedList;         /* Linked list for Data */
  FILE *DataFile = NULL;    /* Pointer to Data file name (from cmd line) */
  int lcv = 0; /* variable for loops */

   /* One command line argument is required: the file name     */
   if (2 == argc) /* note that argc 2 means one argument given */
     {
      /* Print out an opening message with the file name
         then try to open the Data file for input (read mode)   */
         fprintf(stdout, "Opening file : %s\n", argv[1]);
         DataFile = fopen(argv[1], "r");

      /* Verify that file was opened correctly */
      if (NULL != DataFile)
        {
         /* Initialize the linked list */
         InitLinkedList(&TestLinkedList);

         ReadDataList(DataFile, &TestLinkedList);

         /* Close the Data file */
         fclose(DataFile);

         /* Variables to print entries */
         LinkedListNodes *currentNode = TestLinkedList.FrontPtr;
         ElementStructs *currentElement = currentNode->ElementPtr;
         LinkedListNodes *temp;
         /* Print the first 6 entries */
         fprintf(stdout, "First 6 words in linked list:\n");

         for(lcv = 0; lcv < 6; lcv++) {
           fprintf(stdout, "%d %s\n", currentElement->position, currentElement->String);
           temp = currentNode->Next;
           currentNode = temp;
           currentElement = currentNode->ElementPtr;
         }

         /* Print the last 6 entries */
         currentNode = TestLinkedList.BackPtr;
         currentElement = currentNode->ElementPtr;
         fprintf(stdout, "Last 6 words in linked list:\n");
         for(lcv = 0; lcv < 6; lcv++) {
           fprintf(stdout, "%d %s\n", currentElement->position, currentElement->String);
           temp = currentNode->Previous;
           currentNode = temp;
           currentElement = currentNode->ElementPtr;
         }

         /* Print total number of words read */
         fprintf(stdout, "Number of words: %d \n", TestLinkedList.NumElements);

       /* Remove from front of list, print a message */
          ElementStructs* removed = RemoveFromFrontOfLinkedList(&TestLinkedList);
           fprintf(stdout, "Remove from front of list, new front is: %s \n", TestLinkedList.FrontPtr->ElementPtr->String);
           fprintf(stdout, "Removed value is: %s \n", removed->String);
           FREE_DEBUG(removed);
           removed = NULL;


       /* Remove from back of list, print a message */
          removed = RemoveFromBackOfLinkedList(&TestLinkedList);
           fprintf(stdout, "Remove from back of list, new back is: %s \n", TestLinkedList.BackPtr->ElementPtr->String);
           fprintf(stdout, "Removed value is: %s \n", removed->String);
           FREE_DEBUG(removed);
           removed = NULL;

         /* De-allocate the linked list */
         fprintf(stdout, "Destroying the linked list\n");
         DestroyLinkedList(&TestLinkedList);

        } /* if() */
      else
      { /* Error message */
        fprintf(stderr, "Error in file %s at line number %d: file %s was not opened correctly\n", __FILE__, __LINE__, argv[1]);
        ErrorCode = 2;
      } /* if...else() */
     } /* if() */
   else
     { /* Usage message */
       fprintf(stderr, "Error in file %s at line number %d\nINFO: This program takes a file passed in command line and builds a linked list with it. It then displays the first and the last 6 entries and the total number of entries.\nUSAGE: One argument required\n./TestList fileName\n", __FILE__, __LINE__);
       ErrorCode = 1;
     } /* if...else() */

   return ErrorCode;
  } /* main() */

  /******************************************************************************
   Read the data file (assumed to be open) one word at a time placing each
   word into the data structure.  This routine will verify that the input string
   has the correct length.  Any string that is too long will generate a warning
   to stderr, not be added but processing will continue
          void ReadData(FILE *InputFile, LinkedLists *ListPtr)
    Where:
      FILE *InputFile         - Pointer to an open input file
      LinkedLists *ListPtr - Pointer to a storage block which holds the
                                data structure entry
      returns: voi            - nothing is returned.
      errors:                 - This routine will print an error message to
                                stderror and exit with an error code
  ******************************************************************************/
   void ReadDataList(FILE *InputFile, LinkedLists *ListPtr)
    {
     ElementStructs *TempData;             /* temp variable to hold data   */
     int lcv = 1;               /* loop control variable        */
     int strLen;                /* The actual input string length */
     char String[MAX_STR_LEN+2];/* temp variable to hold string */
     char formatStr [32];       /* Used to build the dynamic length */

     /* Build a dynamic format string */
     sprintf(formatStr, "%c%d%c", '%', MAX_STR_LEN+1, 's');

     /* Read the data in from the file into the String buffer */
     while (EOF != fscanf(InputFile, formatStr, String))
       {
        /* Insert code here to make sure the input data is not too long
            hint:  use strlen(String)   */
          strLen = strlen(String);
          if(strLen >= MAX_STR_LEN) {
            fprintf(stderr, "Warning in file %s at line number %d: input data was too long\n", __FILE__, __LINE__);
          }
          TempData = (ElementStructs*) malloc(sizeof(ElementStructs));
          if(NULL == TempData) {
            MALLOC_DEBUG(elem);
            exit(MALLOC_ERROR);
          } /* if() */
          TempData->position = lcv++;
          strncpy(TempData->String, String, MAX_STR_LEN);
          AddToBackOfLinkedList(ListPtr, TempData);
       } /* while() */
    } /* ReadData() */
