/******************************************************************************
 Program to compare the LinkedLists and Dynamic Array Search method.
 Reads in a large list of words and puts them into the data structure,
 then searchs for a word that the user has entered when calling the program.
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ClassErrors.h"
#include "LinkedLists.h"
#include "DynamicArrays.h"
#include "Timers.h"

#define IO_ITERATIONS 100
#define PROCESS_ITERATIONS 5000
#define INITIAL_SIZE (1000)

/* Local functions */
void ReadData(FILE *InputFile, DArray *DynamicArrayPtr);
void ReadDataList(FILE *InputFile, LinkedLists *ListPtr);
/******************************************************************************
 Program to test the Search method by reading the Data file provided on
 the command line into the structure, and then searching a word provided by the user.

 Where: int argc     - the number of parameters on the command line
        char *argv[] - Pointer to the command line parameters
 Returns: 0 - success,
          2 - can't open input file
          1 - Invalid number of parameters
******************************************************************************/
int main(int argc, char* argv[])
  {
  /* declare local variables */
  int ErrorCode = 0;        /* Application error code - 0 is OK */
  LinkedLists TestLinkedList;         /* Linked list for Data */
  FILE *DataFile = NULL;    /* Pointer to Data file name (from cmd line) */

   /* Two command line arguments are required: file name and word to search */
   if (3 == argc)
     {
      /* Print out an opening message with the file name
         then try to open the Data file for input (read mode)   */
         fprintf(stdout, "Opening file : %s\n", argv[1]);

         DECLARE_TIMER(data_timer_list)
         DECLARE_REPEAT_VAR(data_list)
         START_TIMER(data_timer_list)
         BEGIN_REPEAT_TIMING(IO_ITERATIONS,data_list)
         DataFile = fopen(argv[1], "r");

      /* Verify that file was opened correctly */
      if (NULL == DataFile)
        {
          /* Error message */
          fprintf(stderr, "Error in file %s at line number %d: file %s was not opened correctly\n", __FILE__, __LINE__, argv[1]);
          ErrorCode = 2;
          return ErrorCode;
        } /* if */
         /* Initialize the linked list */
         InitLinkedList(&TestLinkedList);

         ReadDataList(DataFile, &TestLinkedList);

         /* Close the Data file */
         fclose(DataFile);

      END_REPEAT_TIMING
      STOP_TIMER(data_timer_list)
      PRINT_TIMER(data_timer_list)
      PRINT_RTIMER(data_timer_list,IO_ITERATIONS)


      fprintf(stdout, "Searching list for word : \"%s\"\n", argv[2]);
      ElementStructs* result;

      DECLARE_TIMER(process_timer_list)
      DECLARE_REPEAT_VAR(process_list)
      START_TIMER(process_timer_list)
      BEGIN_REPEAT_TIMING(PROCESS_ITERATIONS,process_list)

      result = SearchList(&TestLinkedList, argv[2]);

      END_REPEAT_TIMING
      STOP_TIMER(process_timer_list)
      PRINT_TIMER(process_timer_list)
      PRINT_RTIMER(process_timer_list,PROCESS_ITERATIONS)

      if(NULL == result) { /* displays the result */
        fprintf(stdout, "Word \"%s\" wasn't found in the list.\n", argv[2]);
      } else {
        fprintf(stdout, "Word \"%s\" found in the list. It is located at position %d.\n", argv[2], result->position);
      } /* if() else */

      /* De-allocate the linked list */
      fprintf(stdout, "Destroying the linked list\n");
      DestroyLinkedList(&TestLinkedList);

      /* declare more local variables */
       DArray TestDynamicArray;         /* Dynamic Array for Data */
       DataFile = NULL;     /* Pointer to Data file name (from cmd line) */

      /* Try to open the Data file for input (read mode) */

          DECLARE_TIMER(data_timer_array)
          DECLARE_REPEAT_VAR(data_array)
          START_TIMER(data_timer_array)
          BEGIN_REPEAT_TIMING(IO_ITERATIONS,data_array)

          DataFile = fopen(argv[1], "r");

      /* Verify that file was opened correctly */
      if (NULL == DataFile)
        {/* Print error messages */
          fprintf(stderr, "Error in file %s at line number %d: file %s was not opened correctly\n", __FILE__, __LINE__, argv[1]);
          ErrorCode = 2;
          return ErrorCode;
         } /* if */

          CreateDArray(&TestDynamicArray, INITIAL_SIZE);
          ReadData(DataFile, &TestDynamicArray);
          fclose(DataFile);

        END_REPEAT_TIMING
        STOP_TIMER(data_timer_array)
        PRINT_TIMER(data_timer_array)
        PRINT_RTIMER(data_timer_array,IO_ITERATIONS)

        fprintf(stdout, "Searching Darray for word : \"%s\"\n", argv[2]);
        Data* res;

        DECLARE_TIMER(process_timer_array)
        DECLARE_REPEAT_VAR(process_array)
        START_TIMER(process_timer_array)
        BEGIN_REPEAT_TIMING(PROCESS_ITERATIONS,process_array)

        res = SearchDArray(&TestDynamicArray, argv[2]);

        END_REPEAT_TIMING
        STOP_TIMER(process_timer_array)
        PRINT_TIMER(process_timer_array)
        PRINT_RTIMER(process_timer_array,PROCESS_ITERATIONS)

        if(NULL == res) { /* displays the result */
          fprintf(stdout, "Word \"%s\" wasn't found in the Darray.\n", argv[2]);
        } else {
          fprintf(stdout, "Word \"%s\" found in the Darray. It is located at position %d.\n", argv[2], res->Num);
        }
        DestroyDArray(&TestDynamicArray);

     } /* if() */
   else
     { /* Usage message */
       fprintf(stderr, "Error in file %s at line number %d\nINFO: This program takes a file and a word passed in command line, builds a linked list with the file content and serach the list for that word. It then says where the word is located in the list if it was found.\nUSAGE: Two arguments required\n./TestTime fileName word\n", __FILE__, __LINE__);
       ErrorCode = 1;
     } /* if...else() */

   return ErrorCode;
  } /* main() */


  /******************************************************************************
   Read the data file (assumed to be open) one word at a time placing each
   word into the data structure.  This routine will verify that the input string
   has the correct length.  Any string that is too long will generate a warning
   to stderr, not be added but processing will continue
          void ReadData(FILE *InputFile, DArray *DynamicArrayPtr)
    Where:
      FILE *InputFile         - Pointer to an open input file
      DArray *DynamicArrayPtr - Pointer to a storage block which holds the
                                data structure entry
      returns: voi            - nothing is returned.
      errors:                 - This routine will print an error message to
                                stderror and exit with an error code
  ******************************************************************************/
   void ReadData(FILE *InputFile, DArray *DynamicArrayPtr)
    {
     Data TempData;             /* temp variable to hold data   */
     int lcv = 1;               /* loop control variable        */
     int strLen;                /* The actual input string length */
     char String[MAX_STR_LEN+2];/* temp variable to hold string */
     char formatStr [32];       /* Used to build the dynamic length */

     /* Build a dynamic format string */
     sprintf(formatStr, "%c%d%c", '%', MAX_STR_LEN+1, 's');

     /* Read the data in from the file into the String buffer */
     while (EOF != fscanf(InputFile, formatStr, String))
       {
        /* Insert code here to make sure the input data is not too long
            hint:  use strlen(String)   */
          strLen = strlen(String);
          if(strLen >= MAX_STR_LEN) {
            fprintf(stderr, "Warning in file %s at line number %d: input data was too long\n", __FILE__, __LINE__);
          }
          TempData.Num = lcv++;
          strncpy(TempData.String, String, MAX_STR_LEN);
          PushToDArray(DynamicArrayPtr, &TempData);
       } /* while() */
    } /* ReadData() */

    /******************************************************************************
     Read the data file (assumed to be open) one word at a time placing each
     word into the data structure.  This routine will verify that the input string
     has the correct length.  Any string that is too long will generate a warning
     to stderr, not be added but processing will continue
            void ReadData(FILE *InputFile, LinkedLists *ListPtr)
      Where:
        FILE *InputFile         - Pointer to an open input file
        LinkedLists *ListPtr - Pointer to a storage block which holds the
                                  data structure entry
        returns: voi            - nothing is returned.
        errors:                 - This routine will print an error message to
                                  stderror and exit with an error code
    ******************************************************************************/
     void ReadDataList(FILE *InputFile, LinkedLists *ListPtr)
      {
       ElementStructs *TempData;             /* temp variable to hold data   */
       int lcv = 1;               /* loop control variable        */
       int strLen;                /* The actual input string length */
       char String[MAX_STR_LEN+2];/* temp variable to hold string */
       char formatStr [32];       /* Used to build the dynamic length */

       /* Build a dynamic format string */
       sprintf(formatStr, "%c%d%c", '%', MAX_STR_LEN+1, 's');

       /* Read the data in from the file into the String buffer */
       while (EOF != fscanf(InputFile, formatStr, String))
         {
          /* Insert code here to make sure the input data is not too long
              hint:  use strlen(String)   */
            strLen = strlen(String);
            if(strLen >= MAX_STR_LEN) {
              fprintf(stderr, "Warning in file %s at line number %d: input data was too long\n", __FILE__, __LINE__);
            }
            TempData = (ElementStructs*) malloc(sizeof(ElementStructs));
            if(NULL == TempData) {
              MALLOC_DEBUG(elem);
              exit(MALLOC_ERROR);
            } /* if() */
            TempData->position = lcv++;
            strncpy(TempData->String, String, MAX_STR_LEN);
            AddToBackOfLinkedList(ListPtr, TempData);
         } /* while() */
      } /* ReadData() */
