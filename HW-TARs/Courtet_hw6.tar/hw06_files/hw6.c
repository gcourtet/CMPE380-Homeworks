#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include "ClassErrors.h"
#include "poly.h"

#define MAX_STR_LEN (256)
#define TOLERANCE 1E-9

/************************************************************************
  Tests three types of root finding, secant, newton, and bisection,
  based on user input and prints out the timing results.
************************************************************************/
int main(int argc, char* argv[])
{
/*------------------------------------------------------------------------
UI variables with sentential values
------------------------------------------------------------------------*/
  int verbose = 0;
  char* fileName = "";
/*------------------------------------------------------------------------
These variables are used to control the getopt_long_only command line
parsing utility.
------------------------------------------------------------------------*/
  int rc;
  /* getopt_long stores the option index here. */
  int option_index = 0;

  /* This contains the short command line parameters list */
  char *getoptOptions = "i:v"/*"v" */;    /* add lots of stuff here */

  /* This contains the long command line parameter list, it should mostly
  match the short list                                                  */
  struct option long_options[] = {
    /* These options don’t set a flag.
    We distinguish them by their indices. */
    {"verbose",   no_argument,       0, 'v'},
    {"verb",      no_argument,       0, 'v'},
    /* add lots of stuff here */
    {"input",   required_argument,       0, 'i'},
    {"in",   required_argument,       0, 'i'},

    {0, 0, 0, 0}
  };

  opterr = 1;           /* Enable automatic error reporting */
  while ((rc = getopt_long_only(argc, argv, getoptOptions, long_options,
                                        &option_index)) != -1) {

    //     printf("getopt_long_only() returned ='%c' index = '%d'\n",  rc, option_index);
    /* Detect the end of the options. */
    switch (rc) {
      case 'v':                    /* verbose */
        printf("option -v\n");
        verbose = 1;
      break;

      case 'i':                    /* input */
        printf("option -i\n");
        fileName = optarg;
      break;

      case '?':  /* Handled by the default error handler */
      break;

      default:
        printf ("Internal error: undefined option %0xX\n", rc);
        exit(PGM_INTERNAL_ERROR);
    } /* switch */
  } /* end while */

  /*------------------------------------------------------------------------
  Check for command line syntax errors
  ------------------------------------------------------------------------*/
  if ((optind < argc) || 0 == strcmp("", fileName)){
    fprintf(stderr, "Test real polynomials program\n");
    fprintf(stderr, "usage: hw6 -i[nput] fileName <-v[erbose]>\n");
    fprintf(stderr, " e.g:   hw6 -in file -v\n");
    fflush(stderr);
    return(PGM_INTERNAL_ERROR);
  } /* end if error */

  FILE *InputFile = NULL;   /* Pointer to Data file name (from cmd line) */
  InputFile = fopen(fileName, "r"); /* open the file */

  /* if our file isn't NULL */
  if(NULL != InputFile) {

    polynomial *poly = NULL;      /* temp variable to hold data   */
    /* allocate that variable */
    poly = (polynomial*) malloc(sizeof(polynomial));

    /* check for good allocation */
    if(NULL == poly) {
      MALLOC_DEBUG(poly);
      exit(MALLOC_ERROR);
    } /* if */

    int lcv = 0;                /* loop control variable        */
    char String[MAX_STR_LEN+2]; /* temp variable to hold string */
    char* delim = " ";          /* delimiter to split the line */
    char *coeff;                /* string to hold the coefficients read */
    unsigned int coeffSize = 0; /* number of coefficients */
    double complex coefficients[MAX_STR_LEN]; /* array to hold the coefficients */

    /* Read the data in from the file into the String buffer */
    while (NULL != fgets(String, MAX_STR_LEN, InputFile)) {
      /* get the first token */
      coeff = strtok(String, delim);

      /* walk through other tokens */
      while(NULL != coeff) {
        coefficients[lcv++] = atof(coeff) + I * 0.0;
        coeffSize++;
        coeff = strtok(NULL, delim);
      } /* while */

      /* initialize the poly to the correct size */
      initPoly(poly, coeffSize);

      /* initialize the coefficients */
      for(lcv = coeffSize-1; lcv >= 0; lcv--) {
        poly->polyCoef[lcv] = coefficients[(coeffSize-1)-lcv];
      } /* for */

      /* print the roots */
      printRoots (poly, TOLERANCE, verbose);

      /* free the algorithm */
      freePoly(poly);

      /* reinitialize the coefficient size and the loop variable */
      coeffSize = 0;
      lcv = 0;

      /* go to next line */
      fprintf(stdout, "\n");
    } /* while */

    /* clean memory usage */
    FREE_DEBUG(poly);
    poly = NULL;

    /* close the file */
    fclose(InputFile);

    /* return if program succeeded */
    return PGM_SUCCESS;
  } else { /* error opening file */
    fprintf(stderr, "Error in file %s at line number %d: file %s was not opened correctly\n", __FILE__, __LINE__, fileName);

    /* return error code */
    return PGM_FILE_NOT_FOUND;
  } /* if...else */
}
