/***********************************************************************
 * Student C framework to calculate the roots and evaluate polynomials
 * static functions are not REQURED, you are free to implement they way
 * you wish
 * Course: Applied Programming
 * Revised: 2015
 *
 * 10/16/2015 R. Repka  - Removed evalPoly, extern
 * 04/03/2015 R. Repka  - Added cpow() and Horner comments,
 * 10/24/2016 R. Repka  - Updated evalDerivs comments
 * 10/26/2016 R. Repka  - Changed createPoly to initPoly
 ***********************************************************************/
#include </usr/include/complex.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "ClassErrors.h"
#include "poly.h"

#define ZERO 0.00000001
#define ITERATIONS (50) /* maximum iterations for laguerre */

/*---------------------------------------------------------------------------
  Define local functions
---------------------------------------------------------------------------*/
static double complex* quadraticRoots(polynomial *p);
static double complex laguerre(polynomial *p, double tol, int verb);
static polynomial* deflPoly(polynomial *p, double complex root);
static double complex* evalDerivs(polynomial *p, double complex point);
static void printComplex(double complex x);

static int computeDegree(polynomial* poly);
/*---------------------------------------------------------------------------
  Initializes a polynomial data structure with nterms.  This allocates storage
  for the actual polynomial.

  Where: polynomial *p       - Pointer to polynomial data structure to create
         unsigned int nterms - The number of elements to create
  Returns: nothing
  Errors:  prints an error and exits
---------------------------------------------------------------------------*/
void initPoly(polynomial *p, unsigned int nterms){
  /* set the number of terms */
  p->nterms = nterms;

  /* allocate an array for the coefficients */
  double complex* polyCoef = (double complex*) malloc(nterms * sizeof(double complex));

  /* handle the allocation error */
  if(NULL == polyCoef) {
    MALLOC_DEBUG(polyCoef);
    exit(MALLOC_ERROR);
  } /* if */

  /* assign the array of coefficients */
  p->polyCoef = polyCoef;

}


/*---------------------------------------------------------------------------
  Destroys/frees a polynomial

  Where: polynomial *p - Pointer to polynomial data structure to destroy
  Returns: nothing
  Errors:  none
---------------------------------------------------------------------------*/
void freePoly(polynomial *p){
  /* 0 terms now */
  p->nterms = 0;

  /* free the array of coefficients */
  FREE_DEBUG(p->polyCoef);

  /* pointer to coefficients is now null */
  p->polyCoef = NULL;
}


/*---------------------------------------------------------------------------
  This function evaluates a polynomial at a complex point z.
  Don't use the cpow() function, it generates round off errors.  You are
  required to use Horner's factorization

  Were: polynomial *p    - Pointer to the polynomial to evaluate
        double complex z - Point to evaluate
  Returns: double complex- Complex solution
  Errors:  none
---------------------------------------------------------------------------*/
double complex cevalPoly(polynomial *p, double complex z){
  /* result is 0 to begin with */
  double complex result = 0.0 ;

  /* loop variable */
  int i;

  /* using Horner's factorization */
  for(i = p->nterms-1; i >= 0; i--) {
    /* result is previous result * point to evaluate + coefficient */
    /* eg: ax^2 + bx + c = (ax + b)x + c */
    result = result * z + p->polyCoef[i];
  } /* for */

  return result;
}


/*---------------------------------------------------------------------------
 This finds all the roots (real and complex) of a real polynomial.  If there
 is a single root, it solves for it.  If there are two roots then it uses
 the quadratic formula.  If there are more than two roots, it uses Laguerre.
 If a complex root is found then BOTH the + and - roots are deflated from the
 polynomial.

 Where: polynomial *poly - Pointer to an array of polynomial coefficients
        double tolerance - Termination tolerance
        int verb         - Verbose flag indicating whether to print intermediate
                           results or not ( 1 = TRUE, 0 = FALSE

 Returns: double complex *roots - A pointer to a complex root array
 Errors:  prints an error and exits
---------------------------------------------------------------------------*/
double complex* roots(polynomial *poly, double tolerance, int verb){
  /* compute degree of algorithm */
  int degree = computeDegree(poly);

  /* array for result */
  double complex* result = NULL;

  /* compute roots if we have a polynomial */
  if(degree > 0) {
    /* allocate an array for the roots */
    result = (double complex*) malloc(degree * sizeof(double complex));

    /* check for good allocation */
    if(NULL == result) {
      MALLOC_DEBUG(result);
      exit(MALLOC_ERROR);
    } /* if */

    /* initialize all results to 0 */
    for(int i = 0; i < degree; i++) {
      result[i] = 0.0;
    } /* for */

    /* useful for laguerre's method */
    double complex newRoot = 0.0 ; // new result
    polynomial *newPoly = poly; //polynomial for the root finding
    int i = 0; //variable for iterations

    switch(degree) {
      /* 1 root, use simple math */
      case 1:
        result[0] = - newPoly->polyCoef[0] / newPoly->polyCoef[1];
        /* print things if verbose is set */
        if(1 == verb) {
          fprintf(stdout, "\tFound only root using simple math\n");
        } /* if */
      break;

      /* 2 roots, use quadratic */
      case 2:
        ; /* this empty line is necessary for compilation */
        double complex* quads = quadraticRoots(newPoly);
        result[i++] = quads[0];
        result[i] = quads[1];
        FREE_DEBUG(quads);
        quads = NULL;
        /* print things if verbose is set */
        if(1 == verb) {
          fprintf(stdout, "\tFound only two roots through quadratic formula\n");
        } /* if */
      break;

      /* more than 2 roots, use Laguerre */
      default:
        /* print things if verbose is set */
        if(1 == verb) {
          fprintf(stdout, "\tLaguerre's Algorithm( tol = %e )\n", tolerance);
        } /* if */

        /* check if 0 is a root */
        while(fabs(creal(cevalPoly(newPoly, newRoot))) < ZERO && fabs(cimag(cevalPoly(newPoly, newRoot))) < ZERO && degree > 2) {
          /* 0 is a root so we add it to the result */
          result[i] = newRoot;
          /* so we deflate it */
          newPoly = deflPoly(newPoly, newRoot);

          /* print things if verbose is set */
          if(1 == verb) {
            fprintf(stdout, "\t");
            printComplex(result[i++]);
            fprintf(stdout, " was an obvious root\n");
          } /* if */

          /* print things if verbose is set */
          if(1 == verb) {
            fprintf(stdout, "\tDeflated: ");
            printPoly(newPoly);
          } /* if */

          /* update the degree */
          degree = computeDegree(newPoly);
        } /* while */

        /* use laguerre as long as we have a polynomial of degree > 2 */
        while(degree > 2) {
          /* new root is found using Laguerre */
          newRoot = laguerre(newPoly, tolerance, verb);

          /* make sure that Laguerre gave us a root */
          if(isnan(creal(newRoot))) {
            fprintf(stderr, "Error at line %d in file %s : no root found\n", __LINE__, __FILE__);
            exit(PGM_INTERNAL_ERROR);
          } /* if */

          /* add the root to the results */
          result[i++] = newRoot;

          /* deflate that root */
          newPoly = deflPoly(newPoly, newRoot);

          /* if the root was imaginary */
          if(fabs(cimag(newRoot)) > ZERO) {
            /* compute the conjugate as another root */
            newRoot = creal(newRoot) - cimag(newRoot)*I;

            /* add that new root to the result */
            result[i++] = newRoot;

            /* deflate it */
            newPoly = deflPoly(newPoly, newRoot);

            /* print things if verbose is set */
            if(1 == verb) {
              fprintf(stdout, "\tFound imaginary root, deflated twice ");
              printPoly(newPoly);
            } /* if */
          } else {
            /* print things if verbose is set */
            if(1 == verb) {
              fprintf(stdout, "\tFound root ");
              printComplex(newRoot);
              fprintf(stdout, "\n");
              fprintf(stdout, "\tDeflated: ");
              printPoly(newPoly);
            } /* if */
          } /* if the root was imaginary */

          /* update the degree */
          degree = computeDegree(newPoly);
        } /* while degree > 2 */

        /* if we have a polynomial of degree 2 we use quadratic */
        if(2 == degree) {
          /* get the 2 remaining roots using quadratic */
          double complex* quads = quadraticRoots(newPoly);
          result[i++] = quads[0];
          result[i] = quads[1];
          FREE_DEBUG(quads);
          quads = NULL;

          /* print things if verbose is set */
          if(1 == verb) {
            fprintf(stdout, "\tFound final two roots through quadratic formula\n");
          } /* if */

        } /* if we have a simple polynomial remaining after laguerre */
        else if(1 == degree) {
          /* compute root using simple math */
          result[i] = - newPoly->polyCoef[0] / newPoly->polyCoef[1];

          /* print things if verbose is set */
          if(1 == verb) {
            fprintf(stdout, "\tFound final root using simple math\n");
          } /* if */
        } /* if else */

        /* clean memory usage */
        freePoly(newPoly);
        newPoly = NULL;

    } /* switch */
  } else { /* we did not give a polynomial, exit and print nice stuff ! */
    fprintf(stderr, "Error at line %d in file %s : entry is not a valid polynomial: ", __LINE__, __FILE__);
    printPoly(poly);
    exit(PGM_INTERNAL_ERROR);
  } /* if ... else */

  /* return the roots found */
  return result;
}

/*---------------------------------------------------------------------------
  This function evaluates the polynomial derivatives at a point using the
  compact method or another equivalent method.

  If you decide not use the compact all-in-one p,p',p'' evaluation code,
  you can implement this function:
        As separate p, p' and p'' derivatives
        Then evaluate each function separately
        Still returning 3 values
  OR
  You can choose to create functions of your own and not implement this function
  at all

  Where: polynomial *p        - Pointer to a polynomial data to evaluate
         double complex point - The point to evaluate
  Returns: double complex*    - Pointer to an array of evaluated
                                derivatives d, d' and d''
  Errors:  prints an error and exits
---------------------------------------------------------------------------*/
static double complex* evalDerivs(polynomial *p, double complex point){
  /* array of complex to hold the derivatives */
  double complex* result = (double complex*) malloc(3 * sizeof(double complex));

  /* check for good allocation */
  if(NULL == result) {
    MALLOC_DEBUG(result);
    exit(MALLOC_ERROR);
  } /* if */

  /* compute degree of the polynomial */
  int degree = computeDegree(p);

  /* highest coefficient */
  double complex d = p->polyCoef[degree];

  /* other variables for computing the derivatives */
  double complex q = 0.0 , r = 0.0 ;

  /* loop variable */
  int k = 0;

  /* simultaneous evaluation as seen in the class slides */
  for(k = degree-1; k >= 0; k--) {
    r = r * point  + q;
    q = q * point  + d;
    d = d * point + p->polyCoef[k];
  } /* for */

  /* assign the derivatives */
  result[0] = d; /* d */
  result[1] = q; /* d' */
  result[2] = 2 * r; /* d'' */

  /* return the derivatives */
  return result;
}

/*---------------------------------------------------------------------------
  Returns the two roots from a quadratic polynomial

  Where: polynomial *p - Pointer to a 2nd order polynomial
  Returns: double complex* - A pointer to a complex root pair.
  Errors:  prints an error and exits
---------------------------------------------------------------------------*/
static double complex* quadraticRoots(polynomial *p){
  /* compute degree of the polynomial */
  int degree = computeDegree(p);

  /* check that we use a quadratic polynomial and print cool stuff if not */
  if(2 != degree) {
    fprintf(stderr, "Error at line %d in file %s : Polynomial is not quadratic: ", __LINE__, __FILE__);
    printPoly(p);
    exit(PGM_INTERNAL_ERROR);
  } /* if */

  /* array to hold the result */
  double complex* result = (double complex*) malloc(2 * sizeof(double complex));

  /* check for good allocation */
  if(NULL == result) {
    MALLOC_DEBUG(result);
    exit(MALLOC_ERROR);
  } /* if */

  /* get the coefficient from the polynomial : ax^2 + bx + c */
  double complex a = p->polyCoef[2];
  double complex b = p->polyCoef[1];
  double complex c = p->polyCoef[0];

  /* compute delta = b^2 - 4ac */
  double complex delta = b * b - 4 * a * c;

  /* just keep the real value of delta */
  double deltaReal = creal(delta);

  /* we have real roots */
  if(deltaReal > ZERO) {
    /* compute both roots */
    result[0] = (-b + sqrt(deltaReal)) / (2.0 * a);
    result[0] = creal(result[0]) + 0.0 * I;
    result[1] = (-b - sqrt(deltaReal)) / (2.0 * a);
    result[1] = creal(result[1]) + 0.0 * I;
  } /* we have imaginary roots */
  else if(deltaReal < ZERO) {
    /* compute first root and then its conjugate */
    result[0] = (-b + I * sqrt(-deltaReal)) / (2.0 * a);
    if(fabs(creal(result[0])) < ZERO) {
      result[0] = 0.0 + cimag(result[0])*I;
    } /* if */
    if(fabs(cimag(result[0])) < ZERO) {
      result[0] = creal(result[0]) + 0.0*I;
    } /* if */
    result[1] = creal(result[0]) - I * cimag(result[0]);
  }
  else { /* we have a double real root */
    double complex root = - b / (2.0 * a) + I * 0.0;
    root = creal(root) + 0.0 * I;
    result[0] = root;
    result[1] = root;
  } /* if ... else if ... else */

  /* return the result */
  return result;
}


/*---------------------------------------------------------------------------
  Uses Laguerre's method to compute a root of a real polynomial

  Where: polynomial *p - Pointer to a polynomial structure to evaluate
         double tol    - Termination tolerance
         int verb      - Verbose flag indicating whether to print intermediate
                         results or not ( 1 = TRUE, 0 = FALSE
 Returns: double complex - The complex root or (NAN + 0.0*I) if  none is found
 Errors:  none
---------------------------------------------------------------------------*/
static double complex laguerre(polynomial *p, double tol, int verb){
  /* result initialized to NAN */
  double complex result = (NAN + 0.0*I);

  /* compute the degree */
  int degree = computeDegree(p);

  /* initial guess is 0.0 */
  double complex x = 0.0;

  /* loop control variable */
  int i = 0;

  /* variable to hold the denominator for Laguerre */
  double complex denominator = 0.0;

  /* variables to help picking the maximum value for the denominator */
  double complex temp1 = 0.0 , temp2 = 0.0 ;

  double complex H = 0.0 ; /* H(x) */
  double complex G = 0.0 ; /* G(X) */
  double complex L = 0.0 ; /* alpha */

  /* array to hold the derivatives */
  double complex* derivatives = NULL;

  /* loop for a certain number of iterations */
  while(i < ITERATIONS) {
    /* compute the derivatives */
    derivatives = evalDerivs(p, x);

    /* compute G and H */
    G = (derivatives[1] / derivatives[0]);
    H = G * G - (derivatives[2] / derivatives[0]);

    /* get the maximum value for the dominator */
    temp1 = G + csqrt((degree-1) * (degree * H - G * G));
    temp2 = G - csqrt((degree-1) * (degree * H - G * G));

    if(fabs(cimag(x) < ZERO)) {
      if(creal(G) < ZERO) {
        denominator = temp2;
      } else {
        denominator = temp1;
      } /* if else */
    } else {
      denominator = cabs(temp1) > cabs(temp2) ? temp1 : temp2;
    } /* if else */

    /* compute alpha */
    L = degree / denominator;

    /* print things if verbose is set */
    if(1 == verb) {
      fprintf(stdout, "\tit: %d x: %f\n", i, creal(x));
      fprintf(stdout, "\t       G(x): %e\n", creal(G));
      fprintf(stdout, "\t       H(x): %e\n", creal(H));
      fprintf(stdout, "\t       Alpha: %e\n", creal(L));
    } /* if */

    /* clean memory usage */
    FREE_DEBUG(derivatives);
    derivatives = NULL;

    /* we've foud a root ! */
    if(cabs(L) < tol || cabs(cevalPoly(p, x)) < ZERO) {
      /* x is the result */
      result = x;
      /* now we're done */
      break;
    } else {
      /* update the value for x */
      x = x - L;
      /* increment the number of iterations */
      i++;
    } /* if else */
  } /* while */

  /* clean our result a little bit */
  if(fabs(creal(result)) < ZERO) {
    result = 0.0 + cimag(result)*I;
  } /* if */
  if(fabs(cimag(result)) < ZERO) {
    result = creal(result) + 0.0*I;
  } /* if */

  /* return the root found */
  return result;
}

/*---------------------------------------------------------------------------
  Deflates a root from the polynomial, returning the new polynomial

  Where: polynomial *p       - Pointer to the polynomial to deflate
         double complex root - The root to use
  Returns: polynomial *      - Pointer to the deflated polynomial
  Errors:  none
---------------------------------------------------------------------------*/
static polynomial* deflPoly(polynomial *p, double complex root){
  /* variable to hold the temporary result */
  polynomial result;
  initPoly(&result, p->nterms-1);

  /* loop variable */
  int i = 0;

  /* deflation */
  /* first coefficient */
  result.polyCoef[result.nterms-1] = p->polyCoef[p->nterms-1];

  /* do the calculations */
  for(i = result.nterms-2; i>=0; i--) {
    result.polyCoef[i] = result.polyCoef[i+1] * root + p->polyCoef[i+1];
  } /* for */

  /* initialize it to the new size */
  p->nterms = result.nterms;

  /* free our old polynomia coefficients */
  FREE_DEBUG(p->polyCoef);
  p->polyCoef = NULL;

  /* allocate the new coefficients */
  p->polyCoef = result.polyCoef;

  /* return the pointer */
  return p;
}


/*---------------------------------------------------------------------------
  The function prints out complex data

  Where: double complex x - the complex data to print out
  returns:  nothing
  errors:   none
---------------------------------------------------------------------------*/
static void printComplex(double complex x){
  /* if we have an imaginary root */
  if(fabs(cimag(x)) > ZERO) {
    fprintf(stdout, "%g  +  %+gi", creal(x), cimag(x));
  }
  else { /* if the root is real */
    fprintf(stdout, "%g", creal(x));
  } /* if ... else */
}

/*---------------------------------------------------------------------------
  Prints a polynomial
  Where: polynomial *p - Pointer to polynomial data structure to print
  Errors: none
  Returns: nothing
---------------------------------------------------------------------------*/
void printPoly (polynomial *p){
  /* loop variable */
  int i = 0;

  /* print name */
  fprintf(stdout, "P(x) = ");

  /* compute the degree */
  int degree = computeDegree(p);

  /* print highest term */
  printComplex(p->polyCoef[degree]);
  fprintf(stdout, "x^%d", degree);

  /* print the other terms only if different from 0*/
  for(i = degree-1; i >= 0; i--) {
    if(fabs(creal(p->polyCoef[i])) > ZERO || fabs(cimag(p->polyCoef[i])) > ZERO) {
      fprintf(stdout, " + ");
      printComplex(p->polyCoef[i]);
      fprintf(stdout, "x^%d", i);
    }
  } /* for */

  fprintf(stdout, "\n");
}

/*---------------------------------------------------------------------------
  Prints the roots of a polynomial from largest (in magnitude) to smallest

  Where: polynomial *p - Pointer to polynomial data structure to print
  Returns: nothing
  Errors:  none
---------------------------------------------------------------------------*/
void printRoots (polynomial *p, double tolerance, int verb){
  /* print the poly */
  printPoly(p);

  /* variable to hold the roots */
  double complex* rootsFound = NULL;

  /* loop variables */
  int i = 0;
  int j = 0;

  /* variable for sorting the array */
  double complex temp = 0.0 ;

  /* the number of roots = the degree */
  int rootNumbers = computeDegree(p);

  /* get the roots */
  rootsFound = roots(p, tolerance, verb);

  /* sort the root array by magnitude (high to low) */
  for(i = 0; i < rootNumbers; i++) {
    for(j = i+1; j < rootNumbers; j++) {
      if(cabs(rootsFound[i]) < cabs(rootsFound[j])) {
        temp = rootsFound[i];
        rootsFound[i] = rootsFound[j];
        rootsFound[j] = temp;
      } /* if */
    } /* for */
  } /* for */

  /* print the roots */
  fprintf(stdout, "Roots :\n");
  for(i = 0; i < rootNumbers; i++) {
    fprintf(stdout, "\t");
    printComplex(rootsFound[i]);
    fprintf(stdout, "\n");
  } /* for */

  /* clean memory usage */
  FREE_DEBUG(rootsFound);
  rootsFound = NULL;

}


/*---------------------------------------------------------------------------
  Optional helper function to print out x and y value from evaluating
  polynomials, not required

  Where: double complex x - data pair to print
         double complex y -
  Returns: nothing
  Errors:  none
---------------------------------------------------------------------------*/
void printPoint(double complex x, double complex y){
  /* print first complex */
  printComplex(x);

  /* go to next line */
  fprintf(stdout, "\n");

  /* print second complex */
  printComplex(y);
}


/*---------------------------------------------------------------------------
  Function to get the degree of a polynomial

  Where: polynomial* poly - polynomial to get the degree
  Returns: int - the degree of the polynomial
  Errors:  none
---------------------------------------------------------------------------*/
static int computeDegree(polynomial* poly) {
  /* degree is 0 to begin with */
  int degree = 0;

  /* if we have more than 1 term in the polynomial */
  if(poly->nterms > 1) {
    /* go through the coefficients */
    for(int i = 1; i < poly->nterms; i++) {
      /* if that coefficient is different than 0 then we change the degree */
      if(fabs(creal(poly->polyCoef[i])) > ZERO) {
        degree = i;
      } /* if */
    } /* for */
  } /* if */

  /* return the degree that we found */
  return degree;
}
